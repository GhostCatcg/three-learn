# 智慧城市 课程
 
 

## 安装使用

```js
cnpm install //使用国内镜像要快一点
```

或者

```js
npm install
```

    cnpm的安装

```base
   npm install -g cnpm --registry=https://registry.npm.taobao.org
```

安装完成后运行即可

```base
npm run dev
```

打包代码

```base
npm run build:dev
```

运行命令后项目目录下 dist 就是打包文件
